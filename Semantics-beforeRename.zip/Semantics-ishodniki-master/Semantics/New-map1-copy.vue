<!-- Tufts VUE 3.2.2 concept-map (New-map1-copy.vue) 2013-09-10 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/D:/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Tue Sep 10 14:15:28 YEKT 2013 by user on platform Windows XP 5.1 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="New-map1-copy.vue"
    created="1378800153093" x="0.0" y="0.0" width="1.4E-45"
    height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1378800928968"
        spec="C:\Users\Test\source\repos\Ureshipan\Semantics-ishodniki\SemanticsNew-map1-copy.vue"
        type="1" xsi:type="URLResource">
        <title>New-map1-copy.vue</title>
        <property key="File" value="C:\Users\Test\source\repos\Ureshipan\Semantics-ishodniki\SemanticsNew-map1-copy.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/06e8c0d7c0a8000b00f95b1e7c5003d1</URIString>
    <child ID="6"
        label="&#x410;&#x442;&#x43e;&#x43c;&#x430;&#x440;&#x43d;&#x430;&#x44f;&#xa;&#x444;&#x43e;&#x440;&#x43c;&#x443;&#x43b;&#x430;"
        layerID="1" created="1373629525875" x="-950.6667" y="-224.0"
        width="120.0" height="158.66666" strokeWidth="2.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/d2c7042bc0a8000b01592170c4e507f0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7"
        label="&#x424;&#x43e;&#x440;&#x43c;&#x443;&#x43b;&#x430;&#xa;&#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43e;&#x43a;"
        layerID="1" created="1373629629671" x="-818.3334" y="-223.33333"
        width="120.0" height="160.0" strokeWidth="2.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#0AAD1D</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/d2c7042bc0a8000b01592170262f4b1f</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="8"
        label="&#x41e;&#x431;&#x44a;&#x435;&#x434;&#x438;&#x43d;&#x435;&#x43d;&#x438;&#x435;&#xa;&#x438;&#x43b;&#x438; &#x43f;&#x435;&#x440;&#x435;&#x441;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;"
        layerID="1" created="1373629689609" x="-890.16675"
        y="-51.000015" width="275.6667" height="38.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/d2c7042bc0a8000b0159217084313b0f</URIString>
        <point1 x="-889.6667" y="-31.33336"/>
        <point2 x="-615.0" y="-32.666668"/>
    </child>
    <child ID="9"
        label="&#x41d;&#x430;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435; &#x43a;&#x432;&#x430;&#x43d;&#x442;&#x43e;&#x440;&#x430;"
        layerID="1" created="1373629849031" x="-891.5" y="-3.5000095"
        width="275.6667" height="19.0" strokeWidth="1.0" strokeStyle="1"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/d2c7042bc0a8000b0159217099631663</URIString>
        <point1 x="-891.0" y="5.99998"/>
        <point2 x="-616.3333" y="6.000001"/>
    </child>
    <child ID="10"
        label="&#x41e;&#x442;&#x440;&#x438;&#x446;&#x430;&#x43d;&#x438;&#x435;"
        layerID="1" created="1373629912140" x="-891.5" y="31.166672"
        width="278.3333" height="19.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/d2c7042bc0a8000b01592170595f33f4</URIString>
        <point1 x="-891.0" y="40.666668"/>
        <point2 x="-613.6667" y="40.66668"/>
    </child>
    <child ID="11"
        label="&#x41c;&#x43d;&#x43e;&#x436;&#x435;&#x441;&#x442;&#x432;&#x43e;"
        layerID="1" created="1387363871531" x="-687.0" y="-223.41666"
        width="120.0" height="160.0" strokeWidth="2.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/05585c3cc0a8000b0120d5615e1751e5</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="12"
        label="&#x41c;&#x43d;&#x43e;&#x436;&#x435;&#x441;&#x442;&#x432;&#x43e; - &#x444;&#x43e;&#x440;&#x43c;&#x443;&#x43b;&#x430;"
        layerID="1" created="1387364022531" x="-891.1666" y="61.083344"
        width="278.3333" height="19.0" strokeWidth="2.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#DD7B11</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-bold-16</font>
        <URIString>http://vue.tufts.edu/rdf/resource/05585c3cc0a8000b0120d561fc5caba6</URIString>
        <point1 x="-890.6666" y="70.58334"/>
        <point2 x="-613.3333" y="70.58335"/>
    </child>
    <child ID="13"
        label="[  ( x0(-A0 )  ]&#xa;&#x41e;&#x431;&#x43e;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435;&#xa;P0 ( x0 , A0 ) "
        layerID="1" created="1378800156937" x="-354,000000" y="-199,000000"
        width="240,000000" height="160,000000" strokeWidth="2.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/06e8c0d7c0a8000b00f95b1eac61c244</URIString>
        <shape xsi:type="roundRect"/>
    </child>
    <child ID="14"
        label="[  ( x1(-A0 )  ]&#xa;&#x41e;&#x431;&#x43e;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435;&#xa;P0 ( x1 , A0 ) "
        layerID="1" created="1378800156937" x="-84,000000" y="-199,000000"
        width="240,000000" height="160,000000" strokeWidth="2.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/06e8c0d7c0a8000b00f95b1eac61c244</URIString>
        <shape xsi:type="roundRect"/>
    </child>
    <child ID="15"
        label="[  ( x0(-B0 )  ]&#xa;&#x41e;&#x431;&#x43e;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435;&#xa;P0 ( x0 , B0 ) "
        layerID="1" created="1378800156937" x="186,000000" y="-199,000000"
        width="240,000000" height="160,000000" strokeWidth="2.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/06e8c0d7c0a8000b00f95b1eac61c244</URIString>
        <shape xsi:type="roundRect"/>
    </child>
    <layer ID="1" label="Layer 1" created="1378800153093" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/06e8c0f6c0a8000b00f95b1e0b908b0f</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-14.0" y="-14.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0"
            label="&#x41c;&#x430;&#x440;&#x448;&#x440;&#x443;&#x442; &#x431;&#x435;&#x437; &#x438;&#x43c;&#x435;&#x43d;&#x438;"
            created="1378800153078" x="0.0" y="0.0" width="1.4E-45"            height="1.4E-45" strokeWidth="0.0" autoSized="false"
            currentIndex="-1" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/06e8c0f6c0a8000b00f95b1e5052945b</URIString>
            <masterSlide ID="2" created="1378800153125" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/06e8c0f6c0a8000b00f95b1ea03139ac</URIString>
                <titleStyle ID="3" label="Header"
                    created="1378800153156" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/06e8c0f6c0a8000b00f95b1e7c83bf85</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1378800153156" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/06e8c106c0a8000b00f95b1e33dc73d4</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1378800153171"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/06e8c106c0a8000b00f95b1ea93b8699</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2013-09-10</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\Test\source\repos\Ureshipan\Semantics-ishodniki\Semantics</saveLocation>
    <saveFile>C:\Users\Test\source\repos\Ureshipan\Semantics-ishodniki\SemanticsNew-map1-copy.vue</saveFile>
</LW-MAP>